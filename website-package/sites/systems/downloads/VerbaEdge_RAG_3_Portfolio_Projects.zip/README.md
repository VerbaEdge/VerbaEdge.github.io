# VerbaEdge Systems LLC — three focused RAG debugging portfolio case studies

These are three **completed independent technical demonstrations**, each with a reproducible defective baseline, targeted correction, synthetic dataset, before/after measurement, and executable regression tests. They are *not* full RAG applications, customer projects, LLM benchmarks, or security certifications.

| Project | Failure class | Verified local outcome |
| --- | --- | --- |
| 01 Retrieval & metadata | Wrong/missing source chunks and stale records | Hit@1: 50% → 100% (4 synthetic questions) |
| 02 Citation & context | Citation/source mismatch after reranking | Provenance pass: 0% → 100% (3 synthetic cases) |
| 03 Access control | Cross-tenant and restricted chunks exposed in retrieval | Requests with no unauthorized chunks: 0% → 100% (5 synthetic requests) |

## Run all

Use Python 3.9 or newer. No external dependencies or credentials required.

```bash
python verify_all.py
```

Alternatively run each project's `demo.py`, then `python -m unittest discover -s tests -v` in its folder.

See `UPWORK_PROFILE_AND_PORTFOLIO_COPY.md` for honest, copy-ready agency positioning and portfolio descriptions.

## Scope limits

- All data and failure scenarios are synthetic and purpose-built for technical demonstration.
- Project 01 uses lexical ranking to isolate metadata/filter behavior, not an embedding model or vector database.
- Project 02 checks citation provenance and context assembly, **not semantic truth or LLM hallucinations**.
- Project 03 tests access boundaries in an in-memory fixture, **not production-grade authorization guarantees or prompt-injection resistance**.
- No paid work, Upwork contracts, or customer outcomes are claimed.

Copyright 2026 VerbaEdge Systems LLC. All rights reserved.
