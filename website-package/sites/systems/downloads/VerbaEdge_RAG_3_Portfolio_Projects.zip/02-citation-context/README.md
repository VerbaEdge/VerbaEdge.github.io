# RAG citation reliability — stable mapping after reranking and context packing

**Independent technical demonstration · synthetic passages · no client involvement**

## Client-like symptom

An existing RAG system presents an answer citing the wrong source after it reranks retrieved passages. Truncating a packed prompt mid-passage can also strip useful context.

## Root cause reproduced

The baseline sorts retrieved passages by relevance, but constructs its citation dictionary from their **original** order. Labels like `[S1]` then point to the wrong documents. The baseline also clips the context string at an arbitrary character boundary.

## Targeted fix

Sort once, attach stable `source` + `id` metadata to each citation after reranking, pack only complete lines within the configured budget, and evaluate source provenance and required evidence presence. No new chatbot, prompt tuning, or LLM integration.

## Reproduce

```bash
python demo.py
python -m unittest discover -s tests -v
```

Python standard library only. No vector database, LLM, network calls, credentials, or customer documents are used.

## What this demonstrates

- Diagnosis of a citation mapping defect in an existing RAG pipeline
- Clear source identifiers through reranking and context assembly
- Deterministic, budget-limited context packing
- Regression tests for provenance, source evidence presence, and input ordering

See `CASE_STUDY.md` for executed results.

## Limits

This project validates **citation provenance and context construction**, not whether generated natural-language claims are logically supported by sources. Model-grounding and hallucination evaluations require a representative dataset, human judgement, and model calls; those are not simulated as achieved here.
