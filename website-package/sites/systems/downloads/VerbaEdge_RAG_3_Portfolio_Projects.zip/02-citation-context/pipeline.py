"""Context-packing and citation provenance fixture; no generative model calls."""
import re


def _line(label, chunk):
    return f"[{label}] SOURCE={chunk['source']} ID={chunk['id']} TEXT={chunk['text']}"


def baseline_build(case):
    """Deliberate defect: sort context but map citations to unsorted candidates,
    then clip the context string midway through a passage."""
    ranked = sorted(case['candidates'], key=lambda c: -c['score'])
    lines = [_line(f'S{i+1}', c) for i, c in enumerate(ranked)]
    raw = "\n".join(lines)
    mapping = {f'S{i+1}': {'source': c['source'], 'id': c['id']}
               for i, c in enumerate(case['candidates'])}
    return {'context': raw[:case['budget']], 'citations': mapping,
            'included_ids': [c['id'] for c in ranked]}


def fixed_build(case):
    """Rank first, assign citation IDs once, pack whole chunks only."""
    ranked = sorted(case['candidates'], key=lambda c: (-c['score'], c['id']))
    lines, mapping, included = [], {}, []
    consumed = 0
    for candidate in ranked:
        label = f'S{len(included)+1}'
        line = _line(label, candidate)
        additional = len(line) + (1 if lines else 0)
        if consumed + additional > case['budget']:
            continue
        lines.append(line)
        consumed += additional
        mapping[label] = {'source': candidate['source'], 'id': candidate['id']}
        included.append(candidate['id'])
    return {'context': '\n'.join(lines), 'citations': mapping, 'included_ids': included}


def verify_context(assembly, required_id):
    """Verify attribution mechanically; NOT semantic entailment of generated claims."""
    rows = []
    for label, source, chunk_id, content in re.findall(
            r'\[(S\d+)\] SOURCE=([^\s]+) ID=([^\s]+) TEXT=([^\n]*)',
            assembly['context']):
        declared = assembly['citations'].get(label)
        rows.append({'label': label, 'id': chunk_id, 'source': source,
                     'valid_provenance': declared == {'source': source, 'id': chunk_id},
                     'nonempty_content': bool(content.strip())})
    return {'valid_provenance': bool(rows) and all(r['valid_provenance'] for r in rows),
            'required_evidence_present': any(r['id'] == required_id and r['nonempty_content'] for r in rows),
            'whole_lines': bool(assembly['context']) and all(' TEXT=' in line and bool(line.split(' TEXT=', 1)[1].strip()) for line in assembly['context'].splitlines()),
            'rows': rows}


def evaluate(cases, fn):
    details = []
    for case in cases:
        result = verify_context(fn(case), case['required_id'])
        details.append({'question': case['id'], **result})
    n = len(details)
    return {'citation_provenance_pass_rate': sum(r['valid_provenance'] for r in details) / n,
            'evidence_presence_rate': sum(r['required_evidence_present'] for r in details) / n,
            'details': details}
