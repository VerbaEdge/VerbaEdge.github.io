import json
from pathlib import Path
from pipeline import baseline_build, fixed_build, evaluate
ROOT = Path(__file__).parent
cases = json.loads((ROOT / 'data/questions.json').read_text())
for label, builder in [('BEFORE', baseline_build), ('AFTER', fixed_build)]:
    result = evaluate(cases, builder)
    print(f"{label}: provenance_pass={result['citation_provenance_pass_rate']:.0%}; required_evidence_present={result['evidence_presence_rate']:.0%}")
    for r in result['details']:
        print(f"  {r['question']}: citations_correct={r['valid_provenance']}, required_evidence_present={r['required_evidence_present']}")
