# Citation reliability: reranking and context packing

**Portfolio classification:** Independent technical demonstration using synthetic documents. Not customer work, not a production deployment.

## Reported symptom
An answer cites the wrong document after results are reordered.

## Investigation and reproduced cause
Citations are numbered after reranking but their source map still reflects the original candidate order; context can be cut mid-passage.

## Targeted change
Bind source IDs to the post-sort passage order; pack whole passages under a context character budget.

## Test evidence (executed locally, November 12, 2026)

- **Before:** provenance_pass=0%; required_evidence_present=100%
- **After:** provenance_pass=100%; required_evidence_present=100%
- **Automated regression tests:** 5 unit tests passed.

```
BEFORE: provenance_pass=0%; required_evidence_present=100%
  Q1: citations_correct=False, required_evidence_present=True
  Q2: citations_correct=False, required_evidence_present=True
  Q3: citations_correct=False, required_evidence_present=True
AFTER: provenance_pass=100%; required_evidence_present=100%
  Q1: citations_correct=True, required_evidence_present=True
  Q2: citations_correct=True, required_evidence_present=True
  Q3: citations_correct=True, required_evidence_present=True
```

## Method and scope
Measures citation-provenance consistency on three synthetic retrieval cases; does not evaluate semantic truthfulness.

Reproduce with `python demo.py` and verify with `python -m unittest discover -s tests -v`. No API key, paid service, online access, or install is needed.

## What this means for an actual client project
The same debugging workflow—reproduce, inspect the relevant stage, identify root cause, make a scoped correction, run agreed regressions—can be applied to an existing RAG pipeline after reviewing its real code, data, permissions, tools, and deployment constraints. These figures represent **this fixture only**; they are not production improvements or client results.

## Project files
- `pipeline.py`: deliberately failing baseline and focused corrected implementation.
- `data/`: synthetic documents, question fixtures.
- `tests/`: automated regression checks.
- `demo.py`: before/after demonstration.
- `EXECUTED_RESULTS.txt`: complete test execution output.
