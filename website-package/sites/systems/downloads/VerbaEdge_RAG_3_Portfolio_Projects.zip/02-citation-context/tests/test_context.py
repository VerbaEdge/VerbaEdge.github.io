import json
import sys
import unittest
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from pipeline import baseline_build, fixed_build, evaluate, verify_context

class CitationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.cases = json.loads((ROOT / 'data/questions.json').read_text())

    def test_bug_reproduced(self):
        result = evaluate(self.cases, baseline_build)
        self.assertEqual(result['citation_provenance_pass_rate'], 0.0)

    def test_fixed_all_citations_refer_to_actual_chunks(self):
        result = evaluate(self.cases, fixed_build)
        self.assertEqual(result['citation_provenance_pass_rate'], 1.0)
        self.assertEqual(result['evidence_presence_rate'], 1.0)

    def test_fixed_never_partially_truncates_line(self):
        for case in self.cases:
            assembly = fixed_build(case)
            self.assertTrue(verify_context(assembly, case['required_id'])['whole_lines'])
            self.assertLessEqual(len(assembly['context']), case['budget'])

    def test_metadata_stable_when_input_order_changed(self):
        for case in self.cases:
            flipped = {**case, 'candidates': list(reversed(case['candidates']))}
            self.assertEqual(fixed_build(case), fixed_build(flipped))

    def test_small_budget_returns_no_unverified_citation(self):
        case = {**self.cases[0], 'budget': 8}
        output = fixed_build(case)
        self.assertEqual(output['context'], '')
        self.assertEqual(output['citations'], {})

if __name__ == '__main__': unittest.main()
