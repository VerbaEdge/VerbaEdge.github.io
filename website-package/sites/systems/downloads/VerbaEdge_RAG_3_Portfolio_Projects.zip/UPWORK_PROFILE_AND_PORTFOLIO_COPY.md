# Upwork agency profile and portfolio copy

Use on the existing VerbaEdge Systems LLC agency profile. Only the owner or an account administrator can edit.

## Agency tagline
RAG Debugging, Retrieval Reliability & AI Security

## Agency overview (copy-ready)

VerbaEdge Systems LLC helps teams troubleshoot and improve existing Retrieval-Augmented Generation (RAG) applications. We focus on retrieval failures, unreliable citations, missing or stale source passages, document permissions, tenant isolation, and targeted fixes within an existing Python/LLM workflow.

Our approach starts with a reproducible example of what is failing. We trace the relevant ingestion, metadata, search, retrieval, context-construction, citation, or authorization stage; isolate the cause; make a bounded change; and test the result. We favor fixing the current system rather than rebuilding it without evidence.

Typical projects include RAG retrieval diagnostics, metadata/filter bugs, citation mapping, context packing, regression checks, and focused document-access hardening. Security work is scoped engineering review and remediation—not a formal penetration test or compliance certification.

Our technical delivery draws on doctoral-level computer-engineering expertise and research/engineering backgrounds in Python, machine learning, LLM evaluation, AI safety, edge AI, computer vision, embedded systems, and cyber-physical systems. These broader skills support rigorous debugging and systems-level analysis; they remain part of our expertise even though our primary current offer is RAG reliability and access control.

If you already have a RAG system and can share representative failing questions, expected source documents, and the relevant technical stack, we can discuss a focused diagnostic or fix sprint.

## Relevant agency skills (choose only available Upwork taxonomy options)

Retrieval-Augmented Generation (RAG), Python, Large Language Models, Machine Learning, Prompt Engineering, AI Model Evaluation, Natural Language Processing, LangChain (only if hands-on), LangGraph (only if hands-on), Information Retrieval, API Integration, Data Processing, AI Security, Computer Vision, Embedded Systems.

These are search terms and suggestions, not verified Upwork selectable skill labels. Do not list a technology unless the team can credibly deliver it.

## Portfolio entry 1
**Title:** RAG Retrieval Debugging | Metadata Filters & Stale Documents

**Description:** Independent technical case study using synthetic policies to reproduce a document-retrieval defect in an existing RAG-style pipeline. Inconsistent metadata keys hid expected sources, while stale records remained candidates. A bounded normalization and active-version filter change improved Hit@1 from 50% to 100% across four controlled questions. Five unit tests verify the behavior. This is a local lexical retrieval fixture—not a live vector database, customer project, or production result.

## Portfolio entry 2
**Title:** RAG Citation Debugging | Reranking & Context Integrity

**Description:** Independent technical case study reproducing incorrect citation/source mappings after passage reranking. Implemented deterministic citation assignment and whole-passage context packing, then verified citations and required evidence with five tests. Provenance consistency improved from 0% to 100% across three synthetic cases. This measures citation metadata correctness, not LLM answer truthfulness or a client outcome.

## Portfolio entry 3
**Title:** RAG Security Hardening | Tenant Access & Document Isolation

**Description:** Independent technical case study demonstrating how a shared retrieval path can return cross-tenant or role-restricted chunks. Corrected the controlled fixture to authorize documents before ranking, fail closed when identity is missing, and check deleted records and cache scopes. Requests with no unauthorized chunks increased from 0% to 100% over five synthetic cases, with eight tests passing. No live model, vector store, penetration test, or compliance audit was performed.

## Publishing note

Never describe these examples as paid client engagements, production deployments, vector database benchmarks, model-grounding evaluations, or complete security validation. They are reproducible independent samples, and their numerical results only apply to the included synthetic fixtures. Personal research and engineering qualifications can be stated accurately, but should not be presented as company-wide certifications.
