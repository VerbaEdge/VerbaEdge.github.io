import json
from pathlib import Path
from pipeline import baseline_search, secure_search, evaluate
ROOT = Path(__file__).parent
docs = json.loads((ROOT / 'data/documents.json').read_text())
cases = json.loads((ROOT / 'data/questions.json').read_text())
for label, function in [('BEFORE', baseline_search), ('AFTER', secure_search)]:
    result = evaluate(docs, cases, function)
    print(f"{label}: requests_with_no_unauthorized_chunks={result['queries_without_unauthorized_chunks']:.0%}; expected_evidence_present={result['expected_present_rate']:.0%}")
    for row in result['details']:
        print(f"  {row['question']}: returned={row['ids']}, unauthorized={row['unexpected_authorization']}")
