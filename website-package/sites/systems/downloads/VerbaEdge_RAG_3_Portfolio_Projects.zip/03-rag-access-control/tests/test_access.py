import json
import sys
import unittest
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from pipeline import baseline_search, secure_search, evaluate, authorized, context_messages, permission_cache_key

class AccessTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.docs = json.loads((ROOT / 'data/documents.json').read_text())
        cls.cases = json.loads((ROOT / 'data/questions.json').read_text())

    def test_bug_reproduced(self):
        result = evaluate(self.docs, self.cases, baseline_search)
        self.assertLess(result['queries_without_unauthorized_chunks'], 1.0)

    def test_authorization_precedes_ranking(self):
        result = evaluate(self.docs, self.cases, secure_search)
        self.assertEqual(result['queries_without_unauthorized_chunks'], 1.0)
        self.assertEqual(result['expected_present_rate'], 1.0)

    def test_missing_server_principal_fails_closed(self):
        for identity in [None, {}, {'tenant':'alpha'}, {'role':'analyst'}]:
            self.assertEqual(secure_search(self.docs, identity, 'Q4 revenue'), [])

    def test_client_tenant_override_ignored(self):
        who = {'tenant':'alpha', 'role':'analyst'}
        results = secure_search(self.docs, who, 'Q4 revenue forecast', tenant='beta')
        self.assertTrue(all(d['tenant']=='alpha' for d in results))

    def test_role_revocation_blocks_chunk(self):
        altered = [dict(doc) for doc in self.docs]
        for doc in altered:
            if doc['id'] == 'alpha_forecast':
                doc['roles'] = ['admin']
        who = {'tenant':'alpha', 'role':'analyst'}
        self.assertNotIn('alpha_forecast', [d['id'] for d in secure_search(altered, who, 'Q4 revenue forecast')])

    def test_deleted_chunks_not_retrieved(self):
        who = {'tenant':'alpha', 'role':'analyst'}
        self.assertNotIn('alpha_retired', [d['id'] for d in secure_search(self.docs, who, 'old Q4 forecast')])

    def test_untrusted_content_not_a_system_message(self):
        doc = next(d for d in self.docs if d['id']=='alpha_untrusted')
        msgs = context_messages([doc])
        self.assertEqual([m['role'] for m in msgs], ['system', 'user'])
        self.assertNotIn('Ignore previous instructions', msgs[0]['content'])
        self.assertIn('Ignore previous instructions', msgs[1]['content'])

    def test_cache_key_is_scoped_by_principal(self):
        query='Q4 revenue forecast'
        a = permission_cache_key({'tenant':'alpha','role':'analyst'}, query, 'v1')
        b = permission_cache_key({'tenant':'beta','role':'analyst'}, query, 'v1')
        c = permission_cache_key({'tenant':'alpha','role':'admin'}, query, 'v1')
        d = permission_cache_key({'tenant':'alpha','role':'analyst'}, query, 'v2')
        self.assertEqual(len({a,b,c,d}), 4)

if __name__ == '__main__': unittest.main()
