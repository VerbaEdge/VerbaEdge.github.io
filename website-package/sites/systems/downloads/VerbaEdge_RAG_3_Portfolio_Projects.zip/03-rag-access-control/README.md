# RAG document access control — tenant isolation and untrusted data boundaries

**Independent technical demonstration · synthetic documents · no client involvement**

## Client-like symptom

An existing RAG document assistant searches a shared index, returning chunks from another customer tenant or a privileged internal document. Retrieved documents may also contain attacker-controlled instructions.

## Root cause reproduced

The deliberately defective baseline searches every document without enforcing tenant, role, or deletion/retention checks before ranking, then makes the result available to downstream context assembly.

## Targeted fix

Apply mandatory tenant, role, and active-status predicates from a **trusted server-side principal before ranking**. Reject absent or incomplete identity. Ignore a client-provided tenant override. Isolate cache keys by tenant, role, query, and corpus version. Keep retrieved document bytes in a lower-trust message, not the system message.

## Reproduce

```bash
python demo.py
python -m unittest discover -s tests -v
```

No third-party dependencies, internet access, real client records, secrets, vector database, or model calls are used.

## What this demonstrates

- Reproduction of cross-tenant and role-boundary retrieval leaks
- Fail-closed authorization in the retrieval path
- Dynamic role-revocation and deleted-document tests
- Cache-key isolation and untrusted-document role separation

## Limits and security caveats

This proves controls in this **small in-memory fixture only**. A real app needs security enforced inside application authorization logic and database/vector-store query filters, not solely on local post-processing or prompts. Cached content must be invalidated when authorization changes. Separating messages does **not** establish resistance to prompt injection by an actual LLM. This is not a penetration test, certification, or assurance of complete security.

OWASP reference: https://cheatsheetseries.owasp.org/cheatsheets/RAG_Security_Cheat_Sheet.html
