# RAG security hardening: tenant and role isolation

**Portfolio classification:** Independent technical demonstration using synthetic documents. Not customer work, not a production deployment.

## Reported symptom
Shared retrieval leaks other tenant and privileged passages.

## Investigation and reproduced cause
The baseline ranks across a shared corpus before enforcing tenant, role, or deleted-document restrictions.

## Targeted change
Filter by trusted principal before ranking, deny missing identity, isolate cache keys, and keep retrieved text below system instruction trust level.

## Test evidence (executed locally, November 12, 2026)

- **Before:** requests_with_no_unauthorized_chunks=0%; expected_evidence_present=100%
- **After:** requests_with_no_unauthorized_chunks=100%; expected_evidence_present=100%
- **Automated regression tests:** 8 unit tests passed.

```
BEFORE: requests_with_no_unauthorized_chunks=0%; expected_evidence_present=100%
  Q1: returned=['alpha_forecast', 'beta_forecast', 'alpha_retired'], unauthorized=['beta_forecast', 'alpha_retired']
  Q2: returned=['alpha_forecast', 'beta_forecast', 'alpha_retired'], unauthorized=['alpha_forecast', 'alpha_retired']
  Q3: returned=['alpha_forecast', 'beta_forecast', 'alpha_retired'], unauthorized=['alpha_forecast', 'beta_forecast', 'alpha_retired']
  Q4: returned=['alpha_privileged', 'beta_internal', 'alpha_forecast'], unauthorized=['beta_internal']
  Q5: returned=['alpha_privileged', 'beta_internal', 'alpha_forecast'], unauthorized=['alpha_privileged', 'beta_internal', 'alpha_forecast']
AFTER: requests_with_no_unauthorized_chunks=100%; expected_evidence_present=100%
  Q1: returned=['alpha_forecast'], unauthorized=[]
  Q2: returned=['beta_forecast'], unauthorized=[]
  Q3: returned=[], unauthorized=[]
  Q4: returned=['alpha_privileged'], unauthorized=[]
  Q5: returned=[], unauthorized=[]
```

## Method and scope
Measures unauthorized-chunk exposure across five synthetic requests; no real LLM penetration testing.

Reproduce with `python demo.py` and verify with `python -m unittest discover -s tests -v`. No API key, paid service, online access, or install is needed.

## What this means for an actual client project
The same debugging workflow—reproduce, inspect the relevant stage, identify root cause, make a scoped correction, run agreed regressions—can be applied to an existing RAG pipeline after reviewing its real code, data, permissions, tools, and deployment constraints. These figures represent **this fixture only**; they are not production improvements or client results.

## Project files
- `pipeline.py`: deliberately failing baseline and focused corrected implementation.
- `data/`: synthetic documents, question fixtures.
- `tests/`: automated regression checks.
- `demo.py`: before/after demonstration.
- `EXECUTED_RESULTS.txt`: complete test execution output.
