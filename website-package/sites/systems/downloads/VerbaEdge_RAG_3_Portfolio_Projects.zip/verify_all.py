"""Run demos and all unit tests; exits nonzero on any failure."""
from pathlib import Path
import subprocess
import sys

root = Path(__file__).parent
names = ('01-retrieval-metadata', '02-citation-context', '03-rag-access-control')
for name in names:
    d = root/name
    print(f'\n===== {name}: demo =====',flush=True)
    subprocess.run([sys.executable, 'demo.py'], cwd=d, check=True)
    print(f'===== {name}: tests =====',flush=True)
    subprocess.run([sys.executable, '-m', 'unittest', 'discover', '-s', 'tests', '-v'], cwd=d, check=True)
print('\nAll 18 unit tests passed across three independent portfolio demonstrations.')
