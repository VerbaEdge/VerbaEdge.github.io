import json
from pathlib import Path
from pipeline import baseline_retrieve, fixed_retrieve, evaluate

ROOT = Path(__file__).parent
records = json.loads((ROOT / "data/records.json").read_text())
questions = json.loads((ROOT / "data/questions.json").read_text())
for label, retriever in (("BEFORE", baseline_retrieve), ("AFTER", fixed_retrieve)):
    result = evaluate(records, questions, retriever)
    print(f"{label}: Hit@1={result['hit_at_1']:.0%}; Hit@3={result['hit_at_3']:.0%}")
    for row in result["details"]:
        print(f"  {row['question']}: expected={row['expected']}, retrieved={row['retrieved']}")
