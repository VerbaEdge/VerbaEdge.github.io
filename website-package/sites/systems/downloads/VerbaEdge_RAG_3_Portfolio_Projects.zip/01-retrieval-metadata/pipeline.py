"""Isolated retrieval-stage regression fixture; not a vector database or LLM."""
import re
from collections import Counter


def tokens(text):
    return re.findall(r"[a-z0-9]+", text.casefold())


def score(query, record):
    """Transparent lexical overlap scoring to isolate metadata behavior."""
    q = Counter(tokens(query))
    d = Counter(tokens(record["text"]))
    return sum(min(n, d.get(word, 0)) for word, n in q.items())


def baseline_retrieve(records, question, top_k=3):
    """Reproduce a real failure class: assumes one metadata key only."""
    matches = [r for r in records
               if r.get("product") == question["product"]
               and r.get("doc_type") == "policy"]
    return sorted(matches, key=lambda r: (-score(question["query"], r), r["id"]))[:top_k]


def normalize_type(record):
    for key in ("doc_type", "kind", "category"):
        val = record.get(key)
        if isinstance(val, str) and val.strip():
            return val.strip().casefold()
    return None


def fixed_retrieve(records, question, top_k=3):
    """Normalize metadata, exclude drafts/archives, and enforce requested year."""
    matches = [r for r in records
               if r.get("product") == question["product"]
               and r.get("year") == question["year"]
               and r.get("status") == "active"
               and normalize_type(r) == "policy"]
    return sorted(matches, key=lambda r: (-score(question["query"], r), r["id"]))[:top_k]


def evaluate(records, questions, retrieve):
    rows = []
    for q in questions:
        ids = [d["id"] for d in retrieve(records, q)]
        rank = ids.index(q["expected_id"]) + 1 if q["expected_id"] in ids else None
        rows.append({"question": q["id"], "expected": q["expected_id"],
                     "retrieved": ids, "rank": rank, "hit_at_1": rank == 1,
                     "hit_at_3": rank is not None and rank <= 3})
    n = len(rows)
    return {"hit_at_1": sum(x["hit_at_1"] for x in rows) / n,
            "hit_at_3": sum(x["hit_at_3"] for x in rows) / n,
            "details": rows}
