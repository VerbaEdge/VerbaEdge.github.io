# Retrieval debugging: metadata mismatches and stale records

**Portfolio classification:** Independent technical demonstration using synthetic documents. Not customer work, not a production deployment.

## Reported symptom
Document assistant misses indexed policies.

## Investigation and reproduced cause
A metadata normalization error hides documents stored with different field names; an unbounded filter also leaves draft/archived records in the candidate set.

## Targeted change
Normalize metadata aliases, enforce active/version constraints before ranking, and add regression tests.

## Test evidence (executed locally, November 12, 2026)

- **Before:** Hit@1=50%; Hit@3=50%
- **After:** Hit@1=100%; Hit@3=100%
- **Automated regression tests:** 5 unit tests passed.

```
BEFORE: Hit@1=50%; Hit@3=50%
  Q1: expected=atlas_security_2026, retrieved=['atlas_security_2026', 'atlas_security_2025', 'atlas_billing_draft']
  Q2: expected=atlas_retention_2026, retrieved=['atlas_security_2026', 'atlas_billing_draft', 'atlas_security_2025']
  Q3: expected=atlas_billing_2026, retrieved=['atlas_billing_draft', 'atlas_security_2026', 'atlas_security_2025']
  Q4: expected=nimbus_access_2026, retrieved=['nimbus_access_2026', 'nimbus_security_2025']
AFTER: Hit@1=100%; Hit@3=100%
  Q1: expected=atlas_security_2026, retrieved=['atlas_security_2026', 'atlas_billing_2026', 'atlas_retention_2026']
  Q2: expected=atlas_retention_2026, retrieved=['atlas_retention_2026', 'atlas_billing_2026', 'atlas_security_2026']
  Q3: expected=atlas_billing_2026, retrieved=['atlas_billing_2026', 'atlas_retention_2026', 'atlas_security_2026']
  Q4: expected=nimbus_access_2026, retrieved=['nimbus_access_2026']
```

## Method and scope
Measures Hit@1 on four synthetic question/source pairs using lexical ranking; no embeddings or model calls.

Reproduce with `python demo.py` and verify with `python -m unittest discover -s tests -v`. No API key, paid service, online access, or install is needed.

## What this means for an actual client project
The same debugging workflow—reproduce, inspect the relevant stage, identify root cause, make a scoped correction, run agreed regressions—can be applied to an existing RAG pipeline after reviewing its real code, data, permissions, tools, and deployment constraints. These figures represent **this fixture only**; they are not production improvements or client results.

## Project files
- `pipeline.py`: deliberately failing baseline and focused corrected implementation.
- `data/`: synthetic documents, question fixtures.
- `tests/`: automated regression checks.
- `demo.py`: before/after demonstration.
- `EXECUTED_RESULTS.txt`: complete test execution output.
