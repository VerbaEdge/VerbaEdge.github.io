# RAG retrieval debugging — metadata filters and stale document exclusion

**Independent technical demonstration · synthetic data · no client involvement**

## Client-like symptom

An existing document assistant retrieves some policies but misses others even though the documents are indexed. A stale policy can also enter the candidate set.

## Root cause reproduced

The baseline retriever assumes every chunk has `doc_type: policy`. The fixture intentionally contains inconsistent upstream ingestion metadata (`doc_type`, `kind`, `category`). It also ignores document status and version year.

## Targeted fix

Normalize known metadata aliases and compare a canonical policy type. Filter out `draft`/`archived` records, and require the requested year before ranking. No chatbot rebuild or model changes.

## Reproduce

```bash
python demo.py
python -m unittest discover -s tests -v
```

No third-party dependencies, credentials, network calls, live client data, model calls, embeddings, or vector database are used. Lexical token-overlap ranking makes metadata failures reproducible; it is **not a vector-search benchmark**.

## What this demonstrates

- Turning inconsistent retrieval into a reproducible test
- Isolating metadata/filter defects independently of the LLM
- Making a small fix instead of rewriting a RAG stack
- Measuring Hit@1 and Hit@3 on four predefined synthetic questions

See `CASE_STUDY.md` for actual executed baseline and fixed results.

## Limits

Synthetic records are intentionally small. Real deployments require checking the actual ingestion pipeline, embedding/index consistency, security permissions, versioning policy, and representative client evaluation data. This project is not a production or customer outcome.
