import json
import sys
import unittest
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from pipeline import normalize_type, baseline_retrieve, fixed_retrieve, evaluate

class RetrievalTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.records = json.loads((ROOT / 'data/records.json').read_text())
        cls.questions = json.loads((ROOT / 'data/questions.json').read_text())

    def test_bug_reproduced(self):
        before = evaluate(self.records, self.questions, baseline_retrieve)
        self.assertEqual(before['hit_at_1'], .5)

    def test_fixed_expected_documents_first(self):
        after = evaluate(self.records, self.questions, fixed_retrieve)
        self.assertEqual(after['hit_at_1'], 1.0)

    def test_aliases_and_case_normalized(self):
        self.assertEqual(normalize_type({'kind': ' Policy '}), 'policy')
        self.assertEqual(normalize_type({'category': 'POLICY'}), 'policy')

    def test_archived_and_draft_records_excluded(self):
        for q in self.questions:
            result = fixed_retrieve(self.records, q)
            self.assertTrue(all(r['status'] == 'active' and r['year'] == q['year'] for r in result))

    def test_no_product_cross_contamination(self):
        q = self.questions[0]
        self.assertTrue(all(r['product'] == q['product'] for r in fixed_retrieve(self.records, q)))

if __name__ == '__main__': unittest.main()
